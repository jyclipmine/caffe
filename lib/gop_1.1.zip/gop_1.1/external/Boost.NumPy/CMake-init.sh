#!/bin/bash

mkdir build
cd build
cmake -D Boost_NO_BOOST_CMAKE=ON ..