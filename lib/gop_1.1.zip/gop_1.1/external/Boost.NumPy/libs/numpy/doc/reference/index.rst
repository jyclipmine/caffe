Boost.NumPy Reference
=====================

Contents:

.. toctree::
   :maxdepth: 2

   dtype
   ndarray
   unary_ufunc
   binary_ufunc
   multi_iter

